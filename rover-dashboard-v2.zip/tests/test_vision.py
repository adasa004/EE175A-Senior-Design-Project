"""Tests adapters with stubbed dependencies; no real model inference."""
import json
import subprocess
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'backend'))
import vision

class VisionTests(unittest.TestCase):
    def test_openalpr_uses_json_and_reads_result(self):
        fake = subprocess.CompletedProcess([], 0, json.dumps({'results':[{'plate':'7ABC123','confidence':92.5}]}), '')
        with patch.object(vision.shutil, 'which', return_value='/usr/bin/alpr'), patch.object(vision.subprocess, 'run', return_value=fake) as runner:
            plate = vision.recognize_plate(b'fake image', '.jpg')
        self.assertEqual(plate['plate'], '7ABC123')
        self.assertEqual(plate['confidence'], 92.5)
        self.assertIn('-j', runner.call_args.args[0])

    def test_yolo_result_coordinates(self):
        class Box:
            xyxy = [types.SimpleNamespace(tolist=lambda:[20,10,80,40])]
            cls = [0]
            conf = [.9]
        result = types.SimpleNamespace(orig_shape=(100,200), boxes=[Box()], names={0:'person'})
        class FakeModel:
            def predict(self, **kwargs): return [result]
        module = types.SimpleNamespace(YOLO=lambda weights:FakeModel())
        with patch.dict(sys.modules, {'ultralytics':module}):
            vision._model = None
            boxes = vision.detect_objects(b'fake image', '.jpg')
        vision._model = None
        self.assertEqual(boxes[0]['label'], 'person')
        self.assertAlmostEqual(boxes[0]['x'], .1)
        self.assertAlmostEqual(boxes[0]['height'], .3)

if __name__ == '__main__': unittest.main()
