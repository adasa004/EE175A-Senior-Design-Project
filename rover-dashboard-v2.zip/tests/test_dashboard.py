"""Integration tests with a temporary database and simulated model outputs."""
import base64
import json
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'backend'))
import config
import server
import vision

PNG = base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Y9Z4XcAAAAASUVORK5CYII=')
IMAGE = 'data:image/png;base64,' + base64.b64encode(PNG).decode()

class DashboardTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        config.DATABASE = Path(cls.tmp.name) / 'test.db'
        server.initialize()
        cls.http = server.ThreadingHTTPServer(('127.0.0.1', 0), server.Handler)
        cls.base = 'http://127.0.0.1:' + str(cls.http.server_port)
        cls.thread = threading.Thread(target=cls.http.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.http.shutdown(); cls.http.server_close(); cls.thread.join(); cls.tmp.cleanup()

    @classmethod
    def req(cls, path, body=None):
        payload = None if body is None else json.dumps(body).encode()
        req = urllib.request.Request(cls.base + path, data=payload, headers={'Content-Type':'application/json'})
        with urllib.request.urlopen(req, timeout=5) as res:
            return res.read(), res.headers.get_content_type()

    @classmethod
    def j(cls, path, body=None):
        return json.loads(cls.req(path, body)[0])

    def test_workflow_and_persistence(self):
        self.assertIn(b'/styles.css', self.req('/')[0])
        self.assertEqual(self.req('/app.js')[1], 'text/javascript')
        initial = self.j('/api/state')
        self.assertEqual(initial['spaces'], 56)
        demo = self.j('/api/demo', {})['detections'][0]
        with self.assertRaises(urllib.error.HTTPError) as error:
            self.j('/api/review', {'id': demo['id'], 'status': 'Escalated'})
        self.assertEqual(error.exception.code, 400)  # No fake evidence.
        with patch.object(vision, 'recognize_plate', return_value={'plate':'7TEST42','confidence':91.2,'region':'Unknown'}):
            detected = self.j('/api/recognize', {'image': IMAGE})
        scan_id = detected['id']
        reviewed = self.j('/api/review', {'id':scan_id, 'status':'Escalated', 'note':'Check in person'})
        scan = next(d for d in reviewed['detections'] if d['id'] == scan_id)
        self.assertEqual((scan['status'], scan['note'], scan['evidence_saved']), ('Escalated','Check in person',1))
        self.assertEqual(self.req(f'/api/detections/{scan_id}/image')[0], PNG)
        self.assertTrue(next(d for d in self.j('/api/state')['detections'] if d['id'] == scan_id)['evidence_saved'])
        with patch.object(vision, 'detect_objects', return_value=[{'label':'person','confidence':91.0,'x':.1,'y':.1,'width':.2,'height':.3}]):
            self.assertEqual(self.j('/api/objects', {'image':IMAGE})['objects'][0]['label'], 'person')
        self.assertEqual(self.j('/api/mode', {'mode':'Manual'})['mode'], 'Manual')
        status = self.j('/api/telemetry', {'status':'Patrolling','battery':68,'alert':'Test alert'})
        self.assertEqual((status['telemetry']['battery'], status['alerts'][0]['message']), (68, 'Test alert'))
        with self.assertRaises(urllib.error.HTTPError) as error:
            self.j('/api/recognize', {'image':'data:image/png;base64,garbage'})
        self.assertEqual(error.exception.code, 400)
        with patch.object(vision, 'recognize_plate', side_effect=vision.VisionError('OpenALPR not installed')):
            with self.assertRaises(urllib.error.HTTPError) as error:
                self.j('/api/recognize', {'image':IMAGE})
            self.assertEqual(error.exception.code, 503)

if __name__ == '__main__': unittest.main()
