# Parking Rover Operator Dashboard

A local, editable senior design prototype for scanning license plates and reviewing parking records. It has separate frontend and backend files, OpenALPR for plate numbers, an experimental Tesseract state-name fallback, and optional YOLO26n object detection.

**Prototype limitations:** The state feature depends on the current `backend/vision.py` containing the team's Tesseract changes. It suggests states for human review, and can be wrong or return Unknown; it is not a plate-style classifier. There is no real permit database, rover, motor control, or Supabase authentication connected. YOLO detects objects in requested frames; it does not calculate collision risk or stop the rover. Do not use this prototype as a vehicle safety system. It binds to your own computer and has no login; do not expose it to a network or the internet.

## What to install

This guide is for **64-bit Windows**. Each teammate installs these on their own computer:

1. Python 3.12 (recommended for the optional YOLO/PyTorch dependencies).
2. Visual Studio Code.
3. OpenALPR 2.3.0 Windows binary and its bundled runtime files.
4. Tesseract OCR, including English language data.
5. Optional: the Ultralytics Python package and YOLO26n weights for object detection.

The dashboard runs without the optional vision tools, but the associated recognition features need them. Installing the tools and downloading model weights requires internet access. Once installed, the listed recognition steps run locally on your computer.

## 1. Download the project

1. Sign in to GitHub and accept the repository invitation if it is private.
2. Open the repository page, click **Code > Download ZIP**, then extract the ZIP in File Explorer. Alternatively, use GitHub Desktop to clone it.
3. Open VS Code, choose **File > Open Folder**, and select the extracted project folder that directly contains `backend`, `frontend`, and `README.md`.
4. Choose **Terminal > New Terminal**. Use a PowerShell terminal for the commands below. The prompt should be in the project folder; if the folder is nested, open the inner folder containing `backend`.

## 2. Install Python and create a project environment

1. Download Python 3.12 (64-bit) from [python.org](https://www.python.org/downloads/windows/) and install it. Select the option to add Python to PATH if offered. You can keep other Python versions installed.
2. Close and reopen VS Code, open the project folder and a new PowerShell terminal.
3. Check that Python 3.12 is available:

   ```powershell
   py -3.12 --version
   ```

4. Create the virtual environment from the project root:

   ```powershell
   py -3.12 -m venv .venv
   ```

5. Check its Python and update pip:

   ```powershell
   .\.venv\Scripts\python.exe --version
   .\.venv\Scripts\python.exe -m pip install --upgrade pip
   ```

All commands below call the environment's Python directly, so there is no need to activate it or change PowerShell's execution policy. The base dashboard uses the Python standard library; YOLO requires additional packages in step 5.

If `py -3.12` fails, install Python 3.12 and reopen the terminal. Python 3.15 may run the basic site but can lack compatible PyTorch/YOLO packages; use the separate 3.12 environment for YOLO rather than uninstalling Python 3.15.

## 3. Install OpenALPR for plate numbers

1. Visit [OpenALPR releases](https://github.com/openalpr/openalpr/releases). Expand **Assets** under version **2.3.0** if necessary and download the 64-bit Windows ZIP (`openalpr-2.3.0-win-64bit.zip`, or the equivalently named 64-bit Windows ZIP).
2. In File Explorer, right-click the ZIP and choose **Extract All**. Inside the extracted folder, locate `alpr.exe` (Windows may display it as `alpr`) and the adjacent `openalpr.conf`, DLL files, and `runtime_data` folder. Keep the extracted folder together; do not move only the executable.
3. If the release requires the Microsoft Visual C++ runtime, run the included `vc_redist.x64.exe` and follow the installer. If OpenALPR already runs, you can skip this.
4. In PowerShell, set `OPENALPR_COMMAND` to the actual location of **your** `alpr.exe`. For example, change the following to your extracted path:

   ```powershell
   $env:OPENALPR_COMMAND = "C:\path\to\openalpr_64\alpr.exe"
   ```

   To copy a path in Windows, right-click `alpr.exe`, choose **Copy as path**, and paste it between the quotation marks. Keep spaces and the `.exe` extension.

5. Test the command:

   ```powershell
   Test-Path $env:OPENALPR_COMMAND
   & $env:OPENALPR_COMMAND --help
   ```

   `Test-Path` should show `True`; the second command should print usage information. If the program reports missing DLLs or runtime data, recheck the extracted folder and runtime installation.

**Important:** This `$env:` setting lasts only for the current PowerShell terminal. Set it again in every new terminal, **before starting the dashboard**, or permanently configure your own user environment variable in Windows. Do not copy another teammate's personal Windows path.

## 4. Install Tesseract for state-name hints

OpenALPR uses its own OCR for plate numbers. The team's edited `backend/vision.py` separately runs the Tesseract command-line program to look for state names and a California DMV text clue. A Tesseract installation by itself does not add this behavior to an older copy of the code.

1. In PowerShell, install the UB Mannheim Windows build:

   ```powershell
   winget install --id UB-Mannheim.TesseractOCR -e
   ```

   Follow the installer prompts. If `winget` is unavailable, use the [UB Mannheim installer page](https://github.com/UB-Mannheim/tesseract/wiki). Include English (`eng`) language data.
2. Test the default location:

   ```powershell
   & "C:\Program Files\Tesseract-OCR\tesseract.exe" --version
   & "C:\Program Files\Tesseract-OCR\tesseract.exe" --list-langs
   ```

   The second command should include `eng`. If you installed elsewhere, replace the path with the location of your `tesseract.exe`.
3. If your executable is not in the default location, set its path in the terminal that will start the server:

   ```powershell
   $env:TESSERACT_COMMAND = "C:\path\to\Tesseract-OCR\tesseract.exe"
   ```

   The team's edited code uses this variable; it otherwise tries `C:\Program Files\Tesseract-OCR\tesseract.exe`. Like the OpenALPR variable, this lasts for the current terminal only.

**State accuracy:** OCR may fail on cursive, glare, small text, and other plate designs. The current approach scans the full image, so unrelated background text can create a wrong suggestion. Similarity scores are experimental and not a measured probability. Treat every state as unverified and use human review; no guarantee is made for all states or provinces.

## 5. Install YOLO26n object detection (optional)

Run in the project root using the Python 3.12 environment created above:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-vision.txt
```

Download/test the model once (requires internet on the first run):

```powershell
.\.venv\Scripts\python.exe -c "from ultralytics import YOLO; YOLO('yolo26n.pt'); print('YOLO26n loaded')"
```

Ultralytics normally downloads `yolo26n.pt` automatically if it is not already present. Alternatively provide an existing compatible weights file in the terminal before starting the server:

```powershell
$env:YOLO_WEIGHTS = "C:\path\to\yolo26n.pt"
```

The model runs on CPU, although performance varies. For GPU-specific PyTorch installation instructions, consult [PyTorch's installation selector](https://pytorch.org/get-started/locally/). If the installation fails, confirm the environment is running Python 3.12 64-bit and check the error output. See [Ultralytics YOLO26 documentation](https://docs.ultralytics.com/models/yolo26/) for model details.

## 6. Start the website

1. In VS Code, open a PowerShell terminal at the project root.
2. Set `$env:OPENALPR_COMMAND` as in step 3. If needed, set `$env:TESSERACT_COMMAND` and `$env:YOLO_WEIGHTS` as in steps 4 and 5. These variables must be set in the **same terminal** before starting the server.
3. Run:

   ```powershell
   .\.venv\Scripts\python.exe backend/server.py
   ```

4. Open [http://127.0.0.1:8000](http://127.0.0.1:8000) in Chrome, Edge, or another browser. Keep the terminal open while using the site.
5. To stop the server, select the terminal and press **Ctrl+C**. `KeyboardInterrupt` after stopping it can be normal.

`127.0.0.1` refers to the computer running the server. Teammates each run their own local copy; the GitHub repository does not host the dashboard. A production private deployment would require a separately designed authentication and hosting setup.

## 7. Try the dashboard

- **Upload a plate:** Select **Upload image** in the license-plate camera panel. The detection appears in plate history; select **Inspect**. Review the image, number, state suggestion and status.
- **Use a webcam:** Select **Start camera**, allow the browser's permission request, point at a plate, then click **Scan frame**. Preview alone does not automatically scan video.
- **Test object detection:** In the navigation camera panel, start the camera and click **Detect objects**, or upload an image if the panel offers that control. The model analyzes the requested image only.
- **Review:** Use **Mark valid**, **Mark invalid**, or **Escalate & save evidence** after human inspection. These buttons record local decisions; they do not query a permit database or issue tickets.

Some webcams cannot be opened by both camera panels at the same time. Stop one feed before opening the other if necessary. Camera permission typically requires localhost or HTTPS. The local database is `data/rover.db`; it can contain plate images and review notes and should not be uploaded to GitHub.

## 8. Troubleshooting

| Problem | What to check |
| --- | --- |
| OpenALPR not found | Run `Test-Path $env:OPENALPR_COMMAND` in the same terminal before starting the server. Confirm it points to `alpr.exe`, not just the folder. |
| Plate or state incorrect / Unknown | Use a clear, well-lit photo, with the full plate visible. OCR and state detection can fail or misread. Always review. |
| State stays Unknown | Confirm the repository contains the team's modified `vision.py`, Tesseract is installed, and its configured path is correct. Run the Tesseract version test above. |
| `tesseract` not recognized | Run it with its full quoted `.exe` path and set `TESSERACT_COMMAND` as shown above. |
| YOLO missing or import fails | Run the install command with `.venv\Scripts\python.exe`; confirm the server uses the same Python. |
| Weights download fails | Check internet access, then retry the YOLO test, or set `YOLO_WEIGHTS` to a compatible existing file. |
| Port already in use | Stop the other server or run `$env:ROVER_PORT = '8001'` before starting, then open `http://127.0.0.1:8001`. |
| Camera doesn't start | Check browser camera permissions, ensure another application/panel isn't using it, and use localhost. |
| Python indentation error | Run `.\.venv\Scripts\python.exe -m py_compile backend/vision.py` and inspect the reported line. |

## 9. Files and future changes

| Path | Purpose |
| --- | --- |
| `frontend/index.html` | Dashboard layout. |
| `frontend/styles.css` | Colors, spacing and responsive design. |
| `frontend/app.js` | Buttons, browser camera and API requests. |
| `backend/server.py` | Local HTTP API and SQLite review flow. |
| `backend/vision.py` | OpenALPR, Tesseract changes and YOLO adapter. |
| `backend/config.py` | Local server, lot and model settings. |
| `backend/schema.sql` | Database schema. |
| `requirements-vision.txt` | Optional YOLO Python dependencies. |
| `tests/` | Tests for available dashboard features. |

The present video is the operator computer's webcam. Connecting a rover feed, sensor telemetry, an actual permit service, user authentication, and validated hardware controls requires further engineering. Model weights and local executables are not included; follow the installation steps above. OpenALPR and Ultralytics offer AGPL and other licensing arrangements; review their respective license terms before distributing or deploying.

## 10. Working together on GitHub

Keep the repository private and invite teammates under **Settings > Collaborators**. Teammates accept the invitation, then download or clone the repository and follow the setup above. To contribute changes with GitHub Desktop: pull the latest changes, edit and test, enter a commit summary, select **Commit**, then **Push origin**. Agree with your team on branches and review before merging shared work.

Do not commit databases containing plates or images, virtual environments, credentials, or model downloads. Add a `.gitignore` in the project root before the initial commit. If a sensitive file has already been tracked, simply adding `.gitignore` will not remove it from existing commits or history.
