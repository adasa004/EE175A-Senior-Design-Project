'use strict';

// UI state only. Detection records and review decisions live in SQLite.
const app = { data: null, selectedId: null, filter: 'All', streams: {} };
const $ = (id) => document.getElementById(id);
let toastTimer;

function notify(message) {
  $('toast').textContent = message;
  $('toast').classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => $('toast').classList.remove('show'), 6000);
}

async function request(path, body) {
  const options = body === undefined ? {} : {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
  };
  const response = await fetch(path, { ...options, cache: 'no-store' });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
}

function displayTime(value) {
  const time = new Date(value);
  return Number.isNaN(time.getTime()) ? value : time.toLocaleString();
}

function textCell(row, text, bold = false) {
  const cell = document.createElement('td');
  const content = document.createElement(bold ? 'strong' : 'span');
  content.textContent = text;
  cell.append(content);
  row.append(cell);
  return content;
}

function selectDetection(id) {
  app.selectedId = id;
  const item = app.data.detections.find((d) => d.id === id);
  $('review-note').value = item?.note || '';
  render();
}

function render() {
  if (!app.data) return;
  const { detections, mode } = app.data;
  const selected = detections.find((d) => d.id === app.selectedId);
  $('scan-count').textContent = app.data.total_scanned;
  $('review-count').textContent = app.data.needs_review;
  $('spaces-count').textContent = app.data.spaces;
  $('total-spaces').textContent = app.data.spaces;
  $('lot-name').textContent = app.data.lot;
  $('mode-value').textContent = mode;
  const telemetry = app.data.telemetry;
  $('rover-status').textContent = telemetry.status;
  $('battery').textContent = telemetry.battery == null ? '—' : `${telemetry.battery}%`;
  $('rover-status-detail').textContent = telemetry.timestamp ? `Test input · ${displayTime(telemetry.timestamp)}` : 'No rover connected';
  $('battery-detail').textContent = telemetry.timestamp ? 'Local test telemetry' : 'Awaiting telemetry';
  document.querySelectorAll('[data-mode]').forEach((button) => {
    button.classList.toggle('selected', button.dataset.mode === mode);
    button.setAttribute('aria-pressed', String(button.dataset.mode === mode));
  });
  $('history-count').textContent = `/ ${detections.length}`;
  $('plate-number').textContent = selected?.plate || '—';
  $('plate-region').textContent = (selected?.region || 'Unknown').toUpperCase();
  $('plate-certainty').textContent = selected && selected.confidence != null
    ? `OCR confidence: ${Number(selected.confidence).toFixed(1)}% · demo entries use sample values` : 'Select a detection below.';
  $('plate-location').textContent = selected?.location || '—';
  $('plate-time').textContent = selected ? displayTime(selected.captured_at) : '—';
  $('plate-status').textContent = selected?.status || '—';
  $('plate-evidence-state').textContent = selected?.evidence_saved ? 'Evidence saved' : (selected?.has_image ? 'Image captured' : 'No image');
  $('selected-badge').textContent = selected?.status.toUpperCase() || 'NO SELECTION';
  $('selected-badge').classList.toggle('amber', selected?.status === 'Needs Review');
  $('evidence').classList.toggle('has-image', Boolean(selected?.has_image));
  if (selected?.has_image) $('evidence-img').src = `/api/detections/${selected.id}/image`;
  else $('evidence-img').removeAttribute('src');
  document.querySelectorAll('[data-status]').forEach((button) => button.disabled = !selected);
  document.querySelectorAll('[data-filter]').forEach((button) => {
    button.classList.toggle('active', button.dataset.filter === app.filter);
    button.setAttribute('aria-pressed', String(button.dataset.filter === app.filter));
  });
  const shown = detections.filter((item) => app.filter === 'All' || item.status === app.filter);
  const body = $('history-rows');
  body.replaceChildren();
  for (const item of shown) {
    const row = document.createElement('tr');
    row.classList.toggle('selected-row', item.id === app.selectedId);
    textCell(row, item.plate, true);
    textCell(row, item.confidence == null ? '—' : `${Number(item.confidence).toFixed(1)}%`);
    const label = textCell(row, item.status);
    label.className = 'status-label ' + item.status.replace(/\s/g, '-');
    textCell(row, item.location);
    textCell(row, displayTime(item.captured_at));
    const action = document.createElement('td');
    const button = document.createElement('button');
    button.className = 'inspect';
    button.textContent = 'Inspect →';
    button.setAttribute('aria-label', `Inspect ${item.plate}`);
    button.addEventListener('click', () => { selectDetection(item.id); $('plate-number').scrollIntoView({behavior:'smooth',block:'center'}); });
    action.append(button); row.append(action); body.append(row);
  }
  $('history-empty').hidden = shown.length > 0;
  const alerts = $('alerts');
  alerts.replaceChildren();
  if (app.data.alerts.length === 0) {
    const empty = document.createElement('div'); empty.className = 'empty';
    empty.textContent = 'No alerts recorded. Rover connection is not configured.'; alerts.append(empty);
  } else {
    for (const item of app.data.alerts) {
      const el = document.createElement('div'); el.className = 'alert';
      const time = document.createElement('time'); time.textContent = displayTime(item.created_at);
      el.textContent = item.message; el.append(time); alerts.append(el);
    }
  }
}

async function refresh() {
  try {
    app.data = await request('/api/state');
    if (!app.data.detections.some((d) => d.id === app.selectedId)) {
      app.selectedId = (app.data.detections.find((d) => d.status === 'Needs Review') || app.data.detections[0])?.id || null;
      $('review-note').value = app.data.detections.find((d) => d.id === app.selectedId)?.note || '';
    }
    render();
  } catch (error) { notify(`Backend unavailable: ${error.message}`); }
}

async function startCamera(which) {
  if (!navigator.mediaDevices?.getUserMedia) throw new Error('Camera access is unavailable. Open the dashboard through localhost and use a supported browser.');
  const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
  app.streams[which] = stream;
  const video = $(`${which}-video`);
  video.srcObject = stream;
  await video.play();
  $(`${which}-feed`).classList.add('active');
  $(`${which}-start`).disabled = true;
  $(`${which}-stop`).disabled = false;
  $(`${which}-scan`).disabled = false;
}

function stopCamera(which) {
  app.streams[which]?.getTracks().forEach((track) => track.stop());
  delete app.streams[which];
  $(`${which}-video`).srcObject = null;
  $(`${which}-feed`).classList.remove('active');
  $(`${which}-start`).disabled = false;
  $(`${which}-stop`).disabled = true;
  $(`${which}-scan`).disabled = true;
}

function cameraImage(which) {
  const video = $(`${which}-video`);
  if (!video.videoWidth) throw new Error('The camera is not ready yet.');
  const scale = Math.min(1, 1280 / video.videoWidth);
  const canvas = document.createElement('canvas');
  canvas.width = Math.round(video.videoWidth * scale);
  canvas.height = Math.round(video.videoHeight * scale);
  canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL('image/jpeg', 0.85);
}

function fileImage(file) {
  return new Promise((resolve, reject) => {
    if (!file) return reject(new Error('Choose a JPEG or PNG image.'));
    if (!['image/jpeg', 'image/png'].includes(file.type) || file.size > 4 * 1024 * 1024) return reject(new Error('Choose a JPEG or PNG under 4 MB.'));
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Could not read that image.'));
    reader.onload = () => resolve(reader.result);
    reader.readAsDataURL(file);
  });
}

async function recognize(image) {
  notify('Running OpenALPR…');
  const result = await request('/api/recognize', {image});
  if (result.id) { await refresh(); selectDetection(result.id); }
  notify(result.message);
}

async function detectObjects(image) {
  notify('Running YOLO26n…');
  const result = await request('/api/objects', {image});
  const img = new Image();
  img.onload = () => {
    const canvas = $('result-canvas');
    const scale = Math.min(1, 1200 / img.width);
    canvas.width = Math.round(img.width * scale); canvas.height = Math.round(img.height * scale);
    const ctx = canvas.getContext('2d'); ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    ctx.lineWidth = Math.max(2, canvas.width / 400); ctx.font = `${Math.max(12, canvas.width / 50)}px sans-serif`;
    for (const box of result.objects) {
      const x = box.x * canvas.width, y = box.y * canvas.height;
      ctx.strokeStyle = '#c5f086'; ctx.strokeRect(x, y, box.width * canvas.width, box.height * canvas.height);
      ctx.fillStyle = '#183b2c'; ctx.fillRect(x, Math.max(0, y - 20), ctx.measureText(`${box.label} ${box.confidence}%`).width + 8, 20);
      ctx.fillStyle = '#fff'; ctx.fillText(`${box.label} ${box.confidence}%`, x + 4, Math.max(14, y - 5));
    }
    canvas.hidden = false;
  };
  img.src = image;
  $('object-summary').textContent = result.objects.length
    ? `Detected: ${result.objects.map((o) => `${o.label} (${o.confidence}%)`).join(', ')}`
    : 'No objects detected in this frame.';
  notify('Object detection complete.');
}

for (const which of ['plate', 'nav']) {
  $(`${which}-start`).addEventListener('click', async () => { try { await startCamera(which); } catch (e) { notify(e.message); } });
  $(`${which}-stop`).addEventListener('click', () => stopCamera(which));
  $(`${which}-scan`).addEventListener('click', async () => {
    try { const image = cameraImage(which); await (which === 'plate' ? recognize(image) : detectObjects(image)); }
    catch (e) { notify(e.message); }
  });
  $(`${which}-upload`).addEventListener('change', async (event) => {
    try { const image = await fileImage(event.target.files[0]); await (which === 'plate' ? recognize(image) : detectObjects(image)); }
    catch (e) { notify(e.message); } finally { event.target.value = ''; }
  });
}

document.querySelectorAll('[data-filter]').forEach((button) => button.addEventListener('click', () => { app.filter = button.dataset.filter; render(); }));
document.querySelectorAll('[data-status]').forEach((button) => button.addEventListener('click', async () => {
  try {
    app.data = await request('/api/review', {id: app.selectedId, status: button.dataset.status, note: $('review-note').value});
    render(); notify(button.dataset.status === 'Escalated' ? 'Escalated: image and details saved in SQLite.' : 'Human review saved.');
  } catch (e) { notify(e.message); }
}));
document.querySelectorAll('[data-mode]').forEach((button) => button.addEventListener('click', async () => {
  try { app.data = await request('/api/mode', {mode: button.dataset.mode}); render(); notify('Mode changed in simulation only.'); }
  catch (e) { notify(e.message); }
}));
$('demo-detection').addEventListener('click', async () => {
  try { app.data = await request('/api/demo', {}); selectDetection(app.data.detections[0].id); notify('Demo scan added.'); }
  catch (e) { notify(e.message); }
});
window.addEventListener('beforeunload', () => Object.keys(app.streams).forEach(stopCamera));
refresh();
setInterval(refresh, 5000);
