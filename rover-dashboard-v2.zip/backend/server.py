"""Loopback-only dashboard API. No real rover commands are implemented."""
import base64
import binascii
import json
import re
import sqlite3
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse
import config
import vision

FRONTEND = config.PROJECT / 'frontend'

def now():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')

def connect():
    conn = sqlite3.connect(config.DATABASE, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn

def initialize():
    config.DATABASE.parent.mkdir(parents=True, exist_ok=True)
    with connect() as db:
        db.executescript((config.PROJECT / 'backend' / 'schema.sql').read_text(encoding='utf-8'))
        db.execute("INSERT OR IGNORE INTO settings VALUES ('seeded', '0')")
        if db.execute("SELECT value FROM settings WHERE key='seeded'").fetchone()[0] == '0':
            samples = [('7KDX284', 72, 'Needs Review'), ('8NVR521', 94, 'Needs Review'), ('6LMT914', 98, 'Valid')]
            db.executemany('INSERT INTO detections (plate,confidence,region,location,captured_at,status) VALUES (?,?,?,?,?,?)',
                           [(plate, certainty, 'Unknown', config.PARKING_LOT, now(), status) for plate, certainty, status in samples])
            db.execute("UPDATE settings SET value='1' WHERE key='seeded'")
            db.execute("INSERT INTO settings VALUES ('mode','Autonomous')")
            db.execute("INSERT INTO settings VALUES ('telemetry',?)", (json.dumps({'status':'Offline','battery':None,'timestamp':None}),))

def state(db):
    rows = db.execute('SELECT id, plate, confidence, region, location, captured_at, status, note, evidence_saved, image IS NOT NULL AS has_image FROM detections ORDER BY id DESC').fetchall()
    data = [dict(row) for row in rows]
    alerts = [dict(row) for row in db.execute('SELECT message,created_at FROM alerts ORDER BY id DESC LIMIT 20')]
    return {'detections': data, 'needs_review': sum(row['status'] == 'Needs Review' for row in data),
            'total_scanned': len(data), 'spaces': config.PARKING_SPACES, 'lot': config.PARKING_LOT,
            'mode': db.execute("SELECT value FROM settings WHERE key='mode'").fetchone()[0],
            'telemetry': json.loads(db.execute("SELECT value FROM settings WHERE key='telemetry'").fetchone()[0]), 'alerts': alerts}

def decode_image(data):
    raw = data.get('image', '')
    if not isinstance(raw, str) or len(raw) > (config.MAX_IMAGE_BYTES * 4 // 3 + 256):
        raise ValueError('Image is too large (maximum 4 MB).')
    try:
        header, encoded = raw.split(',', 1)
        supported = {'data:image/jpeg;base64': ('.jpg', 'image/jpeg'), 'data:image/png;base64': ('.png', 'image/png')}
        if header not in supported:
            raise ValueError('Only JPEG and PNG images are supported.')
        image = base64.b64decode(encoded, validate=True)
        suffix, mime = supported[header]
        if len(image) > config.MAX_IMAGE_BYTES or not image:
            raise ValueError('Image is empty or too large (maximum 4 MB).')
        if not (image.startswith(b'\xff\xd8\xff') if suffix == '.jpg' else image.startswith(b'\x89PNG\r\n\x1a\n')):
            raise ValueError('Image content does not match its format.')
        return image, suffix, mime
    except (ValueError, binascii.Error) as exc:
        raise ValueError('Invalid image: ' + str(exc)) from exc

class Handler(BaseHTTPRequestHandler):
    def reply(self, status, data, mime='application/json; charset=utf-8'):
        content = data if isinstance(data, bytes) else json.dumps(data).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', mime)
        self.send_header('Content-Length', str(len(content)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        self.wfile.write(content)

    def do_GET(self):
        path = urlparse(self.path).path
        files = {'/': ('index.html', 'text/html; charset=utf-8'), '/styles.css': ('styles.css', 'text/css; charset=utf-8'), '/app.js': ('app.js', 'text/javascript; charset=utf-8')}
        if path in files:
            filename, mime = files[path]
            return self.reply(200, (FRONTEND / filename).read_bytes(), mime)
        if path == '/api/state':
            with connect() as db:
                return self.reply(200, state(db))
        match = re.fullmatch(r'/api/detections/(\d+)/image', path)
        if match:
            with connect() as db:
                row = db.execute('SELECT image,image_type FROM detections WHERE id=?', (int(match.group(1)),)).fetchone()
                if row and row['image']:
                    return self.reply(200, row['image'], row['image_type'])
        return self.reply(404, {'error': 'Not found.'})

    def do_POST(self):
        try:
            origin = self.headers.get('Origin')
            if origin and origin not in (f'http://127.0.0.1:{config.PORT}', f'http://localhost:{config.PORT}'):
                return self.reply(403, {'error': 'Cross-origin request blocked.'})
            size = int(self.headers.get('Content-Length', 0))
            if size < 0 or size > 6 * 1024 * 1024:
                raise ValueError('Request exceeds the size limit.')
            payload = json.loads(self.rfile.read(size) or b'{}')
            if not isinstance(payload, dict):
                raise ValueError('Expected an object.')
            path = urlparse(self.path).path
            if path in ('/api/recognize', '/api/objects'):
                image, suffix, mime = decode_image(payload)
                if path == '/api/objects':
                    return self.reply(200, {'objects': vision.detect_objects(image, suffix)})
                result = vision.recognize_plate(image, suffix)
                if not result or not result['plate']:
                    return self.reply(200, {'detection': None, 'message': 'No plate detected. Try a clearer image.'})
                with connect() as db:
                    cur = db.execute('INSERT INTO detections (plate,confidence,region,location,captured_at,image,image_type) VALUES (?,?,?,?,?,?,?)',
                        (result['plate'], result['confidence'], result['region'], config.PARKING_LOT, now(), image, mime))
                    return self.reply(200, {'id': cur.lastrowid, 'message': 'Plate added for human review.'})
            with connect() as db:
                if path == '/api/review':
                    status = payload.get('status')
                    detection_id = payload.get('id')
                    if status not in ('Valid', 'Invalid', 'Escalated', 'Needs Review') or type(detection_id) is not int:
                        raise ValueError('Invalid review status or detection ID.')
                    row = db.execute('SELECT image IS NOT NULL AS has_image FROM detections WHERE id=?', (detection_id,)).fetchone()
                    if row is None:
                        return self.reply(404, {'error': 'Detection not found.'})
                    if status == 'Escalated' and not row['has_image']:
                        raise ValueError('No image is attached. Capture or upload a plate image before saving evidence.')
                    note = str(payload.get('note', '')).strip()[:500]
                    db.execute('UPDATE detections SET status=?,note=?,evidence_saved=? WHERE id=?',
                               (status, note, 1 if status == 'Escalated' else 0, detection_id))
                elif path == '/api/mode':
                    mode = payload.get('mode')
                    if mode not in ('Manual', 'Autonomous'):
                        raise ValueError('Invalid mode.')
                    db.execute("UPDATE settings SET value=? WHERE key='mode'", (mode,))
                elif path == '/api/demo':
                    number = db.execute('SELECT COUNT(*) FROM detections').fetchone()[0] + 1
                    db.execute('INSERT INTO detections (plate,confidence,location,captured_at) VALUES (?,?,?,?)',
                               (f'DEMO{number:03d}', 74, config.PARKING_LOT, now()))
                elif path == '/api/telemetry':
                    status = payload.get('status')
                    battery = payload.get('battery')
                    if status not in ('Offline', 'Patrolling', 'Completed', 'Standing By', 'System Error'):
                        raise ValueError('Invalid rover status.')
                    if battery is not None and (type(battery) not in (int, float) or not 0 <= battery <= 100):
                        raise ValueError('Battery must be between 0 and 100, or null.')
                    telemetry = {'status': status, 'battery': battery, 'timestamp': now()}
                    db.execute("UPDATE settings SET value=? WHERE key='telemetry'", (json.dumps(telemetry),))
                    message = str(payload.get('alert', '')).strip()[:300]
                    if message:
                        db.execute('INSERT INTO alerts (message,created_at) VALUES (?,?)', (message, now()))
                else:
                    return self.reply(404, {'error': 'Not found.'})
                return self.reply(200, state(db))
        except vision.VisionError as exc:
            return self.reply(503, {'error': str(exc)})
        except (ValueError, TypeError, json.JSONDecodeError) as exc:
            return self.reply(400, {'error': str(exc)})

if __name__ == '__main__':
    initialize()
    print(f'Dashboard: http://{config.HOST}:{config.PORT} (local prototype)', flush=True)
    ThreadingHTTPServer((config.HOST, config.PORT), Handler).serve_forever()
