"""Settings to adjust when connecting your own rover."""
import os
from pathlib import Path

PROJECT = Path(__file__).resolve().parent.parent
DATABASE = Path(os.environ.get('ROVER_DATABASE', PROJECT / 'data' / 'rover.db'))
HOST = '127.0.0.1'  # Local development only: no network authentication is provided.
PORT = int(os.environ.get('ROVER_PORT', '8000'))
PARKING_LOT = 'Lot 10'
PARKING_SPACES = 56
OPENALPR_COMMAND = os.environ.get('OPENALPR_COMMAND', 'alpr')
OPENALPR_COUNTRY = os.environ.get('OPENALPR_COUNTRY', 'us')
OPENALPR_PATTERN = os.environ.get('OPENALPR_PATTERN', '')  # optional, e.g. ca
YOLO_WEIGHTS = os.environ.get('YOLO_WEIGHTS', 'yolo26n.pt')
YOLO_CONFIDENCE = float(os.environ.get('YOLO_CONFIDENCE', '0.35'))
MAX_IMAGE_BYTES = 4 * 1024 * 1024
