"""Adapters for OpenALPR and YOLO26n. Models are installed separately."""
import json
import os
import shutil
import subprocess
import tempfile
from pathlib import Path
import config

class VisionError(Exception):
    pass

def recognize_plate(image, suffix):
    command = shutil.which(config.OPENALPR_COMMAND)
    if not command:
        raise VisionError('OpenALPR was not found. Install the alpr command and its runtime data; see README.')
    path = None
    try:
        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as file:
            file.write(image)
            path = file.name
        args = [command, '-c', config.OPENALPR_COUNTRY, '-j', '-d']
        if config.OPENALPR_PATTERN:
            args.extend(['-p', config.OPENALPR_PATTERN])
        result = subprocess.run(args + [path], capture_output=True, text=True, timeout=45, check=False)
        if result.returncode != 0:
            raise VisionError('OpenALPR failed: ' + (result.stderr.strip() or 'check configuration and runtime data')[:350])
        output = json.loads(result.stdout)
        results = output.get('results', [])
        if not results:
            return None
        first = max(results, key=lambda result: result.get('confidence', 0) or 0)
                # Use OpenALPR's state result when one is available.
        region = str(first.get('region') or 'Unknown')

        # Experimental fallback: look for a California DMV website
        # on the image when OpenALPR could not identify the state.
        if region == 'Unknown':
            tesseract = os.environ.get(
                'TESSERACT_COMMAND',
                r'C:\Program Files\Tesseract-OCR\tesseract.exe'
            )

            try:
                ocr = subprocess.run(
                [tesseract, path, 'stdout', '--psm', '11'],
                    capture_output=True,
                    text=True,
                    timeout=20,
                    check=False
                )

                if ocr.returncode == 0:
                    import re

                    states = [
                        'Alabama', 'Alaska', 'Arizona', 'Arkansas',
                        'California', 'Colorado', 'Connecticut',
                        'Delaware', 'Florida', 'Georgia', 'Hawaii',
                        'Idaho', 'Illinois', 'Indiana', 'Iowa',
                        'Kansas', 'Kentucky', 'Louisiana', 'Maine',
                        'Maryland', 'Massachusetts', 'Michigan',
                        'Minnesota', 'Mississippi', 'Missouri',
                        'Montana', 'Nebraska', 'Nevada',
                        'New Hampshire', 'New Jersey', 'New Mexico',
                        'New York', 'North Carolina', 'North Dakota',
                        'Ohio', 'Oklahoma', 'Oregon', 'Pennsylvania',
                        'Rhode Island', 'South Carolina', 'South Dakota',
                        'Tennessee', 'Texas', 'Utah', 'Vermont',
                        'Virginia', 'Washington', 'West Virginia',
                        'Wisconsin', 'Wyoming'
                    ]

                    # Make spaces and capitalization consistent.
                    text = ' '.join(ocr.stdout.lower().split())
                    found_states = set()

                    # Preserve the California clue that already worked.
                    if 'dmv.ca.gov' in text:
                        found_states.add('California')

                    # Check longer names first, so "West Virginia"
                    # isn't also counted as "Virginia".
                    for state in sorted(states, key=len, reverse=True):
                        pattern = r'\b' + re.escape(state.lower()) + r'\b'

                        if re.search(pattern, text):
                            found_states.add(state)
                            text = re.sub(pattern, ' ', text)
                                        # If no exact match was found, compare longer OCR
                    # words with single-word state names.
                    if not found_states:
                        from difflib import SequenceMatcher

                        words = re.findall(r'[a-z]+', text)
                        scores = []

                        for state in states:
                            # Multi-word states need a different check.
                            if ' ' in state:
                                continue

                            best_score = max(
                                (
                                    SequenceMatcher(
                                        None, word, state.lower()
                                    ).ratio()
                                    for word in words
                                    if len(word) >= 7
                                ),
                                default=0
                            )
                            scores.append((best_score, state))

                        scores.sort(reverse=True)
                        best_score, best_state = scores[0]
                        second_score = scores[1][0]

                        # Suggest only if the best match is reasonably
                        # close and clearly ahead of the next state.
                        if best_score >= 0.73 and best_score - second_score >= 0.10:
                            found_states.add(best_state)
                    # Only suggest a state when the clues agree.
                    if len(found_states) == 1:
                        state = found_states.pop()
                        region = f'{state} (unverified)'
            except (OSError, subprocess.TimeoutExpired):
                # Keep the state unknown if Tesseract is unavailable.
                pass

        return {'plate': str(first.get('plate', '')).upper(),
                'confidence': float(first.get('confidence', 0)),
                'region': region}
    except (subprocess.TimeoutExpired, OSError, ValueError, json.JSONDecodeError) as exc:
        raise VisionError('Could not run OpenALPR: ' + str(exc)) from exc
    finally:
        if path:
            Path(path).unlink(missing_ok=True)

_model = None

def detect_objects(image, suffix):
    """Returns object boxes, not distances, collision predictions, or motion commands."""
    global _model
    try:
        from ultralytics import YOLO
    except ImportError as exc:
        raise VisionError('YOLO is not installed. Install requirements-vision.txt; see README.') from exc
    path = None
    try:
        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as file:
            file.write(image)
            path = file.name
        if _model is None:
            _model = YOLO(config.YOLO_WEIGHTS)
        result = _model.predict(source=path, conf=config.YOLO_CONFIDENCE, verbose=False)[0]
        height, width = result.orig_shape
        boxes = []
        for box in result.boxes:
            x1, y1, x2, y2 = box.xyxy[0].tolist()
            boxes.append({'label': str(result.names[int(box.cls[0])]),
                          'confidence': round(float(box.conf[0]) * 100, 1),
                          'x': x1 / width, 'y': y1 / height,
                          'width': (x2 - x1) / width, 'height': (y2 - y1) / height})
        return boxes
    except Exception as exc:
        raise VisionError('YOLO inference failed. Check the weights and installation: ' + str(exc)[:300]) from exc
    finally:
        if path:
            Path(path).unlink(missing_ok=True)
