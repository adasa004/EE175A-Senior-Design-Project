# Parking Rover Dashboard — laptop webcam + local PaddleOCR

This is the existing operator dashboard with its review queue, filters, simulation, telemetry API, Python server, and SQLite permit demo preserved. It adds Start/Stop Camera and manual Scan Frame OCR. No live motor control is included.

## Windows + VS Code setup

Use **64-bit Python 3.11** for this dependency set. Install Python 3.11 from https://www.python.org/downloads/windows/ if `py -3.11` is unavailable. These instructions use CPU inference; no NVIDIA GPU is required.

1. Extract the ZIP completely. In VS Code choose **File > Open Folder** and open the folder containing `backend`, `dist`, `requirements.txt`, and this README.
2. Choose **Terminal > New Terminal**. Run each line:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe backend/ocr.py
.\.venv\Scripts\python.exe backend/server.py
```

No PowerShell activation or execution-policy change is necessary. PaddlePaddle/PaddleOCR are large dependencies. The `ocr.py` step downloads and caches OCR models; internet is needed for installation and first model setup. Wait for **Models ready** before starting the server. If preparation fails, the terminal shows the installation or model-download error. The ZIP contains application source and dependency specifications, not the Paddle binaries or pretrained model weights.

3. Open **http://127.0.0.1:8000** in Chrome or Edge on this computer. Keep the terminal running.
4. Click **Start Camera** and allow camera access.
5. Hold a clearly printed test plate close to the camera, level and well lit. Click **Scan Frame**. A captured image and suggested readings appear below the camera.
6. Select a suggestion. Compare it with the captured image and correct any characters. Click **Save verified plate** to add it to the existing detection history and check the fictional local permit database.
7. Use the normal review queue for human review. Click **Stop Camera** to release the webcam. Press **Ctrl+C** in the terminal to stop the server.

For later runs, use only:

```powershell
.\.venv\Scripts\python.exe backend/server.py
```

## What OCR does and does not do

PaddleOCR runs locally on the CPU with English PP-OCRv5. It is general text recognition, not a trained vehicle/plate detector. It scans the whole captured image and suggests text containing 4–10 letters/digits with at least one digit. Signs and unrelated text may be suggested. Purely alphabetic vanity plates and split text lines are not handled by this initial filter. A distant, moving, angled, or blurry plate may not be read. Move the test plate close enough to fill much of the image.

OCR confidence is a model score, not a probability that a plate is correct. If you edit the suggested text, the stored confidence becomes 0 so the existing workflow treats that transcription as uncertain. No result is saved automatically. Source labels distinguish operator-confirmed webcam OCR from simulated reads. The location is `Laptop webcam · operator verified`; the route, battery, speed, and permit database remain demo data. No ticket or notification is issued.

Scan Frame sends one JPEG to **your own loopback Python server** (`/api/ocr`). The live video is never continuously sent. Images are processed in memory and are not written to disk by this app. The captured preview is cleared on Stop Camera or leaving the page. An already submitted OCR request can finish locally after Stop Camera; its result is discarded by the page. A save already submitted can still complete. Only confirmed plate text, score, source, and review information go into SQLite. Camera frames are never sent to a remote recognition service. Model installation/downloads may contact package and model hosts; once cached, inference uses local model weights.

## Files

- `dist/index.html`: existing dashboard, webcam controls, captured-frame preview, OCR suggestions, confirmation.
- `backend/ocr.py`: bounded JPEG decoding, lazy local PaddleOCR model, serialized inference, plate-like suggestions. Run directly to prepare models.
- `backend/server.py`: loopback HTTP server, `/api/ocr`, `/api/ocr/confirm`, existing APIs, SQLite source migration.
- `backend/schema.sql`: database tables including source; the server adds `source` to existing databases automatically.
- `requirements.txt`: pinned PaddleOCR/PaddlePaddle versions plus image dependencies.
- `tools/send_test_data.py`: original simulated sender.
- `tests/test_api.py`: original API workflow checks.
- `tests/test_ocr.py`: OCR parsing and request-handler integration checks with a mocked OCR engine; does not download models.

The database is generated at `data/rover.db`. The ZIP excludes existing databases, caches, and virtual environments. To keep your existing review history, stop your old server and copy its `data` folder into this extracted project before starting. Back it up first; startup adds a source column. Original imported records are labeled simulated because the old schema had no provenance.

## Troubleshooting

- **Camera blocked:** allow Camera in the browser site settings and Windows **Settings > Privacy & security > Camera** (Windows 10: **Privacy > Camera**). Enable access for desktop apps. Close other camera apps if the device is busy.
- **Connection refused:** start the server and leave the VS Code terminal running. Use the same computer's normal browser.
- **No suggestions:** improve lighting and focus; hold the plate closer. OCR does not automatically identify vehicle plate regions.
- **PaddleOCR unavailable / missing module:** use `.venv\Scripts\python.exe` for both installation and server launch. Rerun the install and preparation commands above. Read the terminal's full error.
- **No matching distribution:** confirm 64-bit Python 3.11 and a Windows CPU supported by PaddlePaddle. Consult the official installation guide below for platform-specific support.
- **Windows DLL error:** check PaddlePaddle's Windows requirements, including the Microsoft Visual C++ runtime, in the official framework installation guide.
- **Model download failure:** restore internet connectivity and rerun `backend/ocr.py`. Keep the model cache; do not run package/model setup for every scan.
- **Slow first scan:** model initialization happens once per server process. Subsequent scans reuse it. Only one scan runs at a time. Do not repeatedly click while one is processing.
- **Port busy:** stop the older server with Ctrl+C, or set `$env:ROVER_PORT = '8080'` before starting and open `http://127.0.0.1:8080`.

## Existing API and simulation

The server stays bound to `127.0.0.1`; it is a local prototype with no account authentication. Do not expose it on a public network. POST endpoints accept JSON and reject cross-origin browser requests. No camera API keys or remote services are used.

Existing endpoints: `GET /api/state`, `POST /api/telemetry`, `POST /api/detections`, `POST /api/review`, `POST /api/demo/detection`, `POST /api/demo/pause`. See `tools/send_test_data.py` for example telemetry/detection data. Pause patrol only toggles simulated motion; it does not stop the camera. API refresh is every five seconds.

New endpoints:

- `POST /api/ocr`: `{"image":"data:image/jpeg;base64,..."}` returns candidate text and scores without saving a detection. Maximum decoded JPEG 1.5 MB, maximum 2 million pixels.
- `POST /api/ocr/confirm`: `{"plate":"7TEST42","confidence":91.2,"location":"Laptop webcam · operator verified"}` saves an operator-confirmed OCR record and returns dashboard state.

The demo permit threshold remains 85. A no-match is not proof of a parking violation. The `ROVER_DB_PATH` environment variable can select a different database path.

## Checks

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

The tests use temporary databases. OCR integration tests substitute deterministic results; they do not measure model accuracy. Real Windows Paddle inference and camera accuracy must be verified on your laptop after installing dependencies. The original browser-only static demo still works without Python, but OCR and shared SQLite storage require the local backend.

## Official references

- PaddleOCR installation: https://www.paddleocr.ai/main/en/version3.x/installation.html
- PaddlePaddle platform installation: https://www.paddlepaddle.org.cn/install/quick
- PaddleOCR Python pipeline and result fields: https://www.paddleocr.ai/latest/en/version3.x/pipeline_usage/OCR.html

The source targets the PaddleOCR 3.x `predict()` API. Dependency versions are fixed for this project, but a real inference run with those packages has not been performed in the build environment.

Build validation: five parser/request-handler/database checks passed, plus JavaScript syntax and mocked capture/confirm/cleanup checks. Live HTTP tests could not run in the restricted build environment. Actual Paddle model inference and webcam accuracy have not been tested here.
