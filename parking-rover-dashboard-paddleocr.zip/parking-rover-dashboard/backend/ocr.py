"""Local PaddleOCR adapter. Frames are processed in memory, never saved."""
import base64
import binascii
import io
import math
import re
import threading

_engine = None
_lock = threading.Lock()

class OCRUnavailable(RuntimeError):
    pass

class OCRBusy(RuntimeError):
    pass

def get_engine():
    global _engine
    if _engine is None:
        try:
            from paddleocr import PaddleOCR
            _engine = PaddleOCR(lang='en', ocr_version='PP-OCRv5', device='cpu',
                                use_doc_orientation_classify=False,
                                use_doc_unwarping=False, use_textline_orientation=False)
        except Exception as exc:
            raise OCRUnavailable('PaddleOCR could not load. Follow README setup, run backend/ocr.py to download models, and restart the server. Details: ' + str(exc)[:300]) from exc
    return _engine

def candidates_from_results(results):
    found = {}
    for result in results:
        for text, score in zip(result.get('rec_texts', []), result.get('rec_scores', [])):
            # General OCR can read signs too. These are suggestions, not verified plates.
            plate = re.sub(r'[^A-Z0-9]', '', str(text).upper())
            confidence = float(score)
            if 4 <= len(plate) <= 10 and any(c.isdigit() for c in plate) and math.isfinite(confidence):
                row = {'plate': plate, 'text': str(text)[:100], 'confidence': round(max(0, min(1, confidence)) * 100, 1)}
                if plate not in found or row['confidence'] > found[plate]['confidence']:
                    found[plate] = row
    return sorted(found.values(), key=lambda x: x['confidence'], reverse=True)[:10]

def recognize(encoded):
    if not isinstance(encoded, str) or not encoded.startswith('data:image/jpeg;base64,'):
        raise ValueError('Expected a JPEG camera frame.')
    try:
        raw = base64.b64decode(encoded.split(',', 1)[1], validate=True)
    except (ValueError, binascii.Error) as exc:
        raise ValueError('Invalid camera frame encoding.') from exc
    if not raw or len(raw) > 1500000:
        raise ValueError('Camera frame is empty or too large.')
    try:
        from PIL import Image, UnidentifiedImageError
        import numpy as np
    except ImportError as exc:
        raise OCRUnavailable('Install requirements.txt in your project virtual environment first.') from exc
    try:
        with Image.open(io.BytesIO(raw)) as image:
            if image.format != 'JPEG' or image.width * image.height > 2000000:
                raise ValueError('Expected a JPEG frame of at most 2 million pixels.')
            # PaddleOCR numpy input uses BGR channel ordering.
            frame = np.asarray(image.convert('RGB'))[:, :, ::-1].copy()
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError) as exc:
        raise ValueError('Camera frame is not a valid JPEG.') from exc
    if not _lock.acquire(blocking=False):
        raise OCRBusy('OCR is processing another frame. Wait and try again.')
    try:
        return {'candidates': candidates_from_results(get_engine().predict(frame))}
    except OCRUnavailable:
        raise
    except Exception as exc:
        raise OCRUnavailable('Local OCR failed. Check terminal details and PaddleOCR installation. Details: ' + str(exc)[:300]) from exc
    finally:
        _lock.release()

if __name__ == '__main__':
    print('Preparing local CPU OCR models. First run requires internet for model downloads.', flush=True)
    get_engine()
    print('Models ready. Start the server and use Scan Frame.', flush=True)
