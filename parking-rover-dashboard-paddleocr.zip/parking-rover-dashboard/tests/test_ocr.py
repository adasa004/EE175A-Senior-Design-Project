import io
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'backend'))
import ocr
import server

class HandlerTest(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir=ROOT/'tests')
        self.old_db=server.DB_PATH
        server.DB_PATH=Path(self.tmp.name)/'test.db'
        server.initialize()
    def tearDown(self):
        server.DB_PATH=self.old_db
        self.tmp.cleanup()
    def post(self,path,body,origin=None):
        handler=object.__new__(server.Handler)
        handler.path=path
        raw=json.dumps(body).encode()
        handler.headers={'Host':f'127.0.0.1:{server.PORT}','Content-Type':'application/json','Content-Length':str(len(raw))}
        if origin: handler.headers['Origin']=origin
        handler.rfile=io.BytesIO(raw)
        result=[]
        handler.response=lambda status,body: result.append((status,body))
        handler.do_POST()
        return result[0]
    def test_ocr_and_confirm(self):
        with patch.object(server,'recognize',return_value={'candidates':[{'plate':'7TEST42','confidence':92}]}):
            status,body=self.post('/api/ocr',{'image':'frame'})
            self.assertEqual(status,200)
            self.assertEqual(body['candidates'][0]['plate'],'7TEST42')
        status,body=self.post('/api/ocr/confirm',{'plate':'7TEST42','confidence':92,'location':'Laptop webcam'})
        self.assertEqual(status,200)
        self.assertEqual(body['records'][0]['source'],'webcam OCR (operator confirmed)')
        self.assertEqual(body['records'][0]['status'],'Awaiting review')
        with server.connect() as db:
            self.assertEqual(server.state(db)['records'][0]['plate'],'7TEST42')
    def test_errors_and_cross_origin(self):
        for error,status in [(ocr.OCRUnavailable('install'),503),(ocr.OCRBusy('wait'),409),(ValueError('bad image'),400)]:
            with patch.object(server,'recognize',side_effect=error):
                self.assertEqual(self.post('/api/ocr',{'image':'bad'})[0],status)
        self.assertEqual(self.post('/api/ocr',{},origin='https://other.example')[0],403)
        self.assertEqual(self.post('/api/ocr/confirm',{'plate':'???','confidence':92})[0],400)
    def test_existing_permit_review_and_demo(self):
        _,body=self.post('/api/detections',{'plate':'6LMT914','confidence':99})
        self.assertEqual(body['records'][0]['permit'],'Valid permit')
        _,body=self.post('/api/ocr/confirm',{'plate':'6LMT914','confidence':0})
        row=body['records'][0]
        self.assertEqual(row['reason'],'uncertain')
        _,body=self.post('/api/review',{'id':row['id'],'decision':'Reviewed','note':'Checked'})
        self.assertEqual(body['records'][0]['status'],'Reviewed')
        self.assertEqual(self.post('/api/demo/detection',{})[0],200)
        server.initialize() # existing DB migration is idempotent

class CandidateTest(unittest.TestCase):
    def test_filter_deduplicate_and_sort(self):
        result=ocr.candidates_from_results([{'rec_texts':['California','7 ABC 123','7ABC123','!!!','123','SIGN42'], 'rec_scores':[.99,.8,.95,.99,.99,.7]}])
        self.assertEqual([r['plate'] for r in result],['7ABC123','SIGN42'])
        self.assertEqual(result[0]['confidence'],95)
    def test_invalid_frames_fail_before_model_load(self):
        with patch.object(ocr,'get_engine') as engine:
            for value in (None,'https://example.com/image.jpg','data:image/jpeg;base64,!!!'):
                with self.assertRaises(ValueError):ocr.recognize(value)
            engine.assert_not_called()
