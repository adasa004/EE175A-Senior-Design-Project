#!/usr/bin/env bash
set -eo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
source /opt/ros/jazzy/setup.bash
export GZ_PARTITION="lot10-$$"
export ROS_DOMAIN_ID="${LOT10_ROS_DOMAIN_ID:-87}"

python3 make_world.py
gz sim -r lot10_prototype.sdf &
sim_pid=$!
cleanup() {
    kill "$sim_pid" ${bridge_pid:+"$bridge_pid"} 2>/dev/null || true
    wait "$sim_pid" ${bridge_pid:+"$bridge_pid"} 2>/dev/null || true
}
trap cleanup EXIT

/opt/ros/jazzy/lib/ros_gz_bridge/parameter_bridge --ros-args -p config_file:="$PWD/bridge.yaml" &
bridge_pid=$!
echo "For the camera in another ROS terminal, export ROS_DOMAIN_ID=$ROS_DOMAIN_ID."
if [[ ${1:-} == --manual ]]; then
    echo "Keep this terminal focused to drive. i = forward, j/l = turn, k = stop."
    ros2 run teleop_twist_keyboard teleop_twist_keyboard
else
    python3 patrol.py
fi
