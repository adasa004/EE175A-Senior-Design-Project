# Senior Design

ROS 2 and Gazebo starter for the UCR Lot 10 parking rover. The first milestone is to drive down an aisle, point the camera at a synthetic plate, and verify the permit decision separately with a simulated OCR observation.

## Prerequisites

Use Ubuntu 24.04 with [ROS 2 Jazzy](https://docs.ros.org/en/jazzy/Installation/Ubuntu-Install-Debs.html). After setting up the ROS apt repository and installing Jazzy, install the [matching Gazebo Harmonic integration](https://gazebosim.org/docs/harmonic/ros_installation/).

```bash
sudo apt install ros-jazzy-ros-gz ros-jazzy-teleop-twist-keyboard ros-jazzy-rqt-image-view
```

## Drive the rover

Close any older Gazebo demo, then run this from the project folder:

```bash
bash drive_lot10.sh
```

The launcher starts an automatic patrol. The rover scans the south outer row heading east, comes back for the south inner row, and uses the west bend to reach the north aisle. It scans the north inner row heading east and the north outer row heading west, then stops. The rover drives 1.5 meters toward the row it is scanning. At each occupied stall it turns toward the rear plate and pauses for three seconds of simulation time. The terminal reports each permit decision and flags two demo violations for human review. The patrol uses known car positions and Gazebo's rover pose, with no OCR or obstacle avoidance.

To drive manually, launch with `bash drive_lot10.sh --manual`. Focus the terminal and use `i` to drive, `j` or `l` to turn, and `k` to stop. Press Ctrl+C in the terminal to end either mode.

Open the camera viewer in a separate terminal and select `/plate_camera/image`:

```bash
source /opt/ros/jazzy/setup.bash
export ROS_DOMAIN_ID=87
ros2 run rqt_image_view rqt_image_view
```

Use the same ROS domain in other terminals for diagnostics or the permit demo. If you override the launcher's `LOT10_ROS_DOMAIN_ID`, use that value instead.

Check `ros2 topic hz /plate_camera/image` for incoming frames and `ros2 topic echo /odom --once` for odometry. During a scan stop, the camera should face the parked car’s rear plate.

## Test the permit decision

Run `python3 permit_check.py` in a sourced Jazzy terminal. In another, run `ros2 topic echo /permit/result`. Send this synthetic observation from a third sourced terminal.

```bash
ros2 topic pub --once /plate/read std_msgs/msg/String \
  'data: "{\"plate\":\"7CDE482\",\"confidence\":0.95}"'
```

| Plate | Confidence | Expected status |
| --- | --- | --- |
| 8ABC271 | 0.95 | permitted |
| 7CDE482 | 0.95 | flagged_candidate |
| 7CDE482 | 0.75 | review |
| 9BDF603 | 0.95 | permitted |

The confidence threshold comes from the review workflow in the project brief. All plates and permits are synthetic. The test input represents the future OCR node's output. Its JSON fields are `plate` and `confidence` in the range 0–1. Treat flagged candidates as cases for human review.

## Build toward a Lot 10 replica

1. The current 82 × 42 m model approximates the loop described for Lot 10, with two connected aisles, stalls on both sides, a central island, and an entrance opening. The [UCR parking map](https://parking.ucr.edu/maps) identifies the lot. Use a scaled overhead image or field measurements to verify its perimeter, entrances, and stall layout.
2. Drive one complete loop and capture plate frames at several distances and angles. Use realistic synthetic plate textures when evaluating OCR.
3. Add a detector and OCR node that consumes `/plate_camera/image` and publishes `/plate/read`. Compare reads with the simulated ground truth, including blurred, oblique, and partially occluded views. Track exact-match rate and false flags separately.
4. Add range sensing, localization, and Nav2 after the manual drive works. Start with fixed waypoints and a stop at each scan pose. Add obstacle handling before autonomous patrols.
