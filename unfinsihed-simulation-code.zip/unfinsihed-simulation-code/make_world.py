"""Generate a self-contained Gazebo world for the parking demo."""
import argparse
from pathlib import Path
from xml.etree import ElementTree as ET


AISLE_Y = 10
TURN_X = 33
# (plate, x, y, heading). Rear plates face the aisle.
PARKED_CARS = (
    ("8DFE504", 24.7, -16, -1), ("7ABC853", -24.7, 16, 1),
    ("7CDE482", -19.5, -16, -1), ("6DEA715", -6.5, -16, -1),
    ("8EAF329", 6.5, -16, -1), ("7FBC946", 19.5, -16, -1),
    ("8ABC271", -11.7, -4, 1), ("9DAC518", -24.7, -4, 1),
    ("6EBD237", 1.3, -4, 1), ("8FAD654", 14.3, -4, 1),
    ("9BDF603", 11.7, 4, -1), ("7BCE183", -24.7, 4, -1),
    ("9ACE562", -11.7, 4, -1), ("6DBF801", 24.7, 4, -1),
    ("8CFA427", -19.5, 16, 1), ("7EDF619", -6.5, 16, 1),
    ("9FAB372", 6.5, 16, 1), ("6BAE935", 19.5, 16, 1),
)


def add(parent, tag, value=None, **attributes):
    element = ET.SubElement(parent, tag, attributes)
    if value is not None:
        element.text = str(value)
    return element


def plugin(parent, library, system, settings=()):
    node = add(parent, "plugin", filename=f"gz-sim-{library}-system",
               name=f"gz::sim::systems::{system}")
    for key, value in settings:
        add(node, key, value)


def shape(link, name, size, color, pose="0 0 0 0 0 0", collide=True):
    visual = add(link, "visual", name=name)
    for element in [visual] + ([add(link, "collision", name=f"{name}_collision")] if collide else []):
        add(element, "pose", pose)
        geometry = add(element, "geometry")
        if isinstance(size, str):
            add(add(geometry, "box"), "size", size)
        else:
            cylinder = add(geometry, "cylinder")
            add(cylinder, "radius", size[0])
            add(cylinder, "length", size[1])
    material = add(visual, "material")
    add(material, "ambient", color)
    add(material, "diffuse", color)
    return visual


def static_model(world, name, pose):
    model = add(world, "model", name=name)
    add(model, "static", "true")
    add(model, "pose", pose)
    return add(model, "link", name="body")


def inertia(link, mass, diagonal):
    node = add(link, "inertial")
    add(node, "mass", mass)
    tensor = add(node, "inertia")
    for axis, value in zip(("ixx", "iyy", "izz"), diagonal):
        add(tensor, axis, value)


def rover(world):
    model = add(world, "model", name="rover")
    add(model, "pose", f"{-TURN_X} {-AISLE_Y} 0.23 0 0 0")
    base = add(model, "link", name="base_link")
    inertia(base, 8, (0.12, 0.22, 0.32))
    shape(base, "chassis", "0.62 0.40 0.18", "0.1 0.45 0.16 1")
    joints = []
    for side, y in (("left", 0.26), ("right", -0.26)):
        for axle, x in (("front", 0.22), ("rear", -0.22)):
            name = f"{axle}_{side}"
            wheel = add(model, "link", name=name)
            add(wheel, "pose", f"{x} {y} -0.10 0 0 0")
            inertia(wheel, 0.4, (0.002, 0.003, 0.002))
            shape(wheel, "tire", (0.12, 0.075), "0.05 0.05 0.05 1",
                  "0 0 0 1.570796 0 0")
            joint = add(model, "joint", name=f"{name}_joint", type="revolute")
            add(joint, "parent", "base_link")
            add(joint, "child", name)
            add(add(joint, "axis"), "xyz", "0 1 0")
            joints.append((f"{side}_joint", f"{name}_joint"))
    plugin(model, "diff-drive", "DiffDrive", joints + [
        ("wheel_separation", 0.52), ("wheel_radius", 0.12),
        ("topic", "/cmd_vel"), ("odom_topic", "/odom"),
        ("frame_id", "odom"), ("child_frame_id", "base_link"),
    ])
    plugin(model, "pose-publisher", "PosePublisher", [
        ("publish_link_pose", "false"),
        ("publish_nested_model_pose", "false"),
        ("publish_model_pose", "true"),
        ("use_pose_vector_msg", "false"),
        ("update_frequency", 25),
    ])
    sensor = add(base, "sensor", name="plate_camera", type="camera")
    add(sensor, "pose", "0.32 0 0.24 0 0 0")
    add(sensor, "topic", "/plate_camera/image")
    add(sensor, "always_on", "true")
    add(sensor, "update_rate", 15)
    camera = add(sensor, "camera")
    add(camera, "horizontal_fov", 0.9)
    image = add(camera, "image")
    add(image, "width", 1920)
    add(image, "height", 1080)
    clip = add(camera, "clip")
    add(clip, "near", 0.05)
    add(clip, "far", 50)


def plate(link, number):
    shape(link, "plate", "0.025 0.32 0.16", "0.96 0.96 0.96 1",
          "-2.27 0 0.47 0 0 0", False)
    # Each hexadecimal value encodes one row of a five-pixel-wide glyph.
    glyphs = {
        "0": "0e 11 13 15 19 11 0e", "1": "04 0c 04 04 04 04 0e",
        "2": "0e 11 01 02 04 08 1f", "3": "1e 01 01 0e 01 01 1e",
        "4": "02 06 0a 12 1f 02 02", "5": "1f 10 10 1e 01 01 1e",
        "6": "0e 10 10 1e 11 11 0e", "7": "1f 01 02 04 08 08 08",
        "8": "0e 11 11 0e 11 11 0e", "9": "0e 11 11 0f 01 01 0e",
        "A": "0e 11 11 1f 11 11 11", "B": "1e 11 11 1e 11 11 1e",
        "C": "0f 10 10 10 10 10 0f", "D": "1e 11 11 11 11 11 1e",
        "E": "1f 10 10 1e 10 10 1f", "F": "1f 10 10 1e 10 10 10",
    }
    for index, character in enumerate(number):
        for row, mask in enumerate(glyphs[character].split()):
            for column in range(5):
                if int(mask, 16) & (16 >> column):
                    y = (3 - index) * .042 + (2 - column) * .007
                    z = .47 + (3 - row) * .014
                    shape(link, f"glyph_{index}_{row}_{column}", "0.005 0.007 0.014",
                          "0.02 0.04 0.16 1", f"-2.286 {y} {z} 0 0 0", False)


def build_world():
    sdf = ET.Element("sdf", version="1.9")
    world = add(sdf, "world", name="lot10_prototype")
    plugin(world, "physics", "Physics")
    plugin(world, "user-commands", "UserCommands")
    plugin(world, "scene-broadcaster", "SceneBroadcaster")
    plugin(world, "sensors", "Sensors", [("render_engine", "ogre2")])
    sun = add(world, "light", name="sun", type="directional")
    add(sun, "pose", "0 0 10 0 0 0")
    add(sun, "diffuse", "0.9 0.9 0.9 1")
    add(sun, "direction", "-0.3 0.2 -1")
    scene = add(world, "scene")
    add(scene, "ambient", "0.6 0.6 0.6 1")
    asphalt = static_model(world, "asphalt", "0 0 -0.1 0 0 0")
    shape(asphalt, "surface", "82 42 0.2", "0.17 0.17 0.18 1")
    island = static_model(world, "center_island", "0 0 0 0 0 0")
    shape(island, "landscaping", "57.2 2 0.18", "0.28 0.38 0.20 1",
          "0 0 0.09 0 0 0")
    markings = static_model(world, "markings", "0 0 0 0 0 0")
    paint = "0.95 0.95 0.8 1"
    # The two main aisles connect at both ends. Each has an outer
    # parking row and an inner row facing the landscaped median.
    for row, y in enumerate((-16, -4, 4, 16)):
        back = y + (2.5 if y in (-4, 16) else -2.5)
        shape(markings, f"back_{row}", "57.2 0.09 0.008", paint,
              f"0 {back} 0.005 0 0 0", False)
        for index in range(23):
            x = (index - 11) * 2.6
            shape(markings, f"stripe_{row}_{index}", "0.09 5 0.008", paint,
                  f"{x} {y} 0.005 0 0 0", False)
    # Leave the east connector open to the south as an entrance.
    for name, x, y, length, yaw in [
        ("west_edge", -38, 0, 37, 1.570796),
        ("east_edge", 38, 0, 37, 1.570796),
        ("north_edge", 0, 18.5, 76, 0),
        ("south_edge", -3, -18.5, 70, 0),
    ]:
        edge = static_model(world, name, f"{x} {y} 0.08 0 0 {yaw}")
        shape(edge, "curb", f"{length} 0.24 0.16", "0.66 0.65 0.61 1")
    colors = ("0.1 0.2 0.65 1", "0.6 0.1 0.1 1", "0.4 0.45 0.48 1",
              "0.8 0.8 0.76 1", "0.28 0.35 0.25 1")
    for index, (number, x, y, heading) in enumerate(PARKED_CARS):
        yaw = heading * 1.570796
        color = colors[index % len(colors)]
        car = static_model(world, f"car_{number}", f"{x} {y} 0 0 0 {yaw}")
        shape(car, "body", "4.5 1.85 0.70", color, "0 0 0.51 0 0 0")
        shape(car, "cabin", "2.2 1.55 0.50", "0.09 0.13 0.17 1",
              "0.20 0 1.08 0 0 0")
        plate(car, number)
    rover(world)
    return ET.ElementTree(sdf)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path, nargs="?", default=Path("lot10_prototype.sdf"))
    args = parser.parse_args()
    tree = build_world()
    ET.indent(tree)
    tree.write(args.output, encoding="utf-8", xml_declaration=True)
