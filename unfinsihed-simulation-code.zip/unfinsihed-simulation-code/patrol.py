"""Drive both sides of each aisle using Gazebo's simulated rover pose."""
import json
import math
import time

import rclpy
from geometry_msgs.msg import PoseStamped, Twist
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data

from make_world import AISLE_Y, PARKED_CARS, TURN_X
from permit_check import classify


def route():
    for aisle in (-AISLE_Y, AISLE_Y):
        for row, direction in ((aisle - 6, 1), (aisle + 6, -1)):
            scan_y = aisle + math.copysign(1.5, row - aisle)
            yield -direction * TURN_X, scan_y, None, None
            cars = sorted((car for car in PARKED_CARS if car[2] == row),
                          key=lambda car: direction * car[1])
            for plate, x, _, _ in cars:
                yield x, scan_y, math.copysign(math.pi / 2, row - aisle), plate
            yield direction * TURN_X, scan_y, None, None
            yield direction * TURN_X, aisle, None, None


class Patrol(Node):
    def __init__(self):
        super().__init__("lot10_patrol")
        self.commands = self.create_publisher(Twist, "/cmd_vel", 10)
        self.create_subscription(PoseStamped, "/patrol/rover_pose", self.update_pose,
                                 qos_profile_sensor_data)
        self.goals = iter(route())
        self.goal = next(self.goals)
        self.scan_start = None
        self.last_pose = 0.0
        self.create_timer(0.25, self.stop_if_pose_missing)
        self.get_logger().info("Waiting for Gazebo. Patrol will start automatically.")

    def stop_if_pose_missing(self):
        if time.monotonic() - self.last_pose > 0.5:
            self.commands.publish(Twist())

    def update_pose(self, rover):
        if self.goal is None:
            return
        self.last_pose = time.monotonic()
        x, y, heading, plate = self.goal
        p, q = rover.pose.position, rover.pose.orientation
        yaw = math.atan2(2 * (q.w * q.z + q.x * q.y),
                         1 - 2 * (q.y * q.y + q.z * q.z))
        distance = math.hypot(x - p.x, y - p.y)
        command = Twist()
        if self.scan_start is not None:
            stamp = rover.header.stamp
            elapsed = stamp.sec + stamp.nanosec * 1e-9 - self.scan_start
            if elapsed >= 3.0:
                result = classify(json.dumps({"plate": plate, "confidence": 0.95}))
                if result["status"] == "flagged_candidate":
                    self.get_logger().warning(
                        f"PARKING VIOLATION FLAG: {plate} has no valid permit. Human review required."
                    )
                else:
                    self.get_logger().info(f"Plate {plate}: valid permit.")
                self.advance()
        elif distance > 0.16:
            error = math.remainder(math.atan2(y - p.y, x - p.x) - yaw, math.tau)
            command.angular.z = max(-1.2, min(1.2, 2.5 * error))
            if abs(error) < 0.25:
                command.linear.x = min(1.5, distance)
        elif heading is not None:
            error = math.remainder(heading - yaw, math.tau)
            if abs(error) > 0.07:
                command.angular.z = max(-1.2, min(1.2, 2.5 * error))
            else:
                stamp = rover.header.stamp
                self.scan_start = stamp.sec + stamp.nanosec * 1e-9
                self.get_logger().info(f"Scanning plate {plate} for 3 simulated seconds")
        else:
            self.advance()
        self.commands.publish(command)

    def advance(self):
        self.scan_start = None
        self.goal = next(self.goals, None)
        if self.goal is None:
            self.get_logger().info("Patrol complete. Rover stopped.")


def main():
    rclpy.init()
    patrol = Patrol()
    try:
        rclpy.spin(patrol)
    except KeyboardInterrupt:
        pass
    finally:
        patrol.destroy_node()
        rclpy.try_shutdown()


if __name__ == "__main__":
    main()
